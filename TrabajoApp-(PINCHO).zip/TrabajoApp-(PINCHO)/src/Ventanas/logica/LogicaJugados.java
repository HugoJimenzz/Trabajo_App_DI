/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas.logica;

import Ventanas.dto.Jugados;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HugoJiménezAriza
 */
public class LogicaJugados {
    private static List<Jugados> listaJugados = new ArrayList<>();
    
    public static void anadirJugados(Jugados jugados){
        listaJugados.add(jugados);
    }

    public static List<Jugados> getListaJugados() {
        return listaJugados;
    }
}
