/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas.dto;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author HugoJiménezAriza
 */
public class Usuario {
    private String nombre ;
    private String  nombreUsuario;
    private String  email;
    private String  contrasena;
    private Date  fechaNaci;
    private String  sexo;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

    public Usuario(String nombre, String nombreUsuario, String email, String contrasena, Date fechaNaci, String sexo) {
        this.nombre = nombre;
        this.nombreUsuario = nombreUsuario;
        this.email = email;
        this.contrasena = contrasena;
        this.fechaNaci = fechaNaci;
        this.sexo = sexo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public Date getFechaNaci() {
        return fechaNaci;
    }

    public void setFechaNaci(Date fechaNaci) {
        this.fechaNaci = fechaNaci;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    public String[] toArrayStringU(){
        String[] u = new String[6];
        u[0] = nombre ;
        u[1] = nombreUsuario;
        u[2] = email;
        u[3] = contrasena;
        u[4] = sdf.format(fechaNaci);
        u[5] = sexo;
        
                
        return u;
    }
}
