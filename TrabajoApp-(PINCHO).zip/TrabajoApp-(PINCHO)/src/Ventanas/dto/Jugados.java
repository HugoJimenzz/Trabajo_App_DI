/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas.dto;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import static java.time.LocalDateTime.now;
import java.util.Date;

/**
 *
 * @author HugoJiménezAriza
 */
public class Jugados {
    private String nombre;
    private String plataforma;
    private Integer duracion;
    private String calificacion;
    private String fallos;
    private Date fechaAlta;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

    public Jugados(String nombre, String plataforma, Integer duracion, String calificacion, String fallos, Date fechaAlta) {
        this.nombre = nombre;
        this.plataforma = plataforma;
        this.duracion = duracion;
        this.calificacion = calificacion;
        this.fallos = fallos;
        this.fechaAlta = fechaAlta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public Integer getDuracion() {
        return duracion;
    }

    public void setDuracion(Integer duracion) {
        this.duracion = duracion;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    public String getFallos() {
        return fallos;
    }

    public void setFallos(String fallos) {
        this.fallos = fallos;
    }
    
    public Date getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Date fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    
    //pillamos los datos
    public String[] toArrayStringJ(){
        String[] j = new String[6];
        j[0] = nombre ;
        j[1] = plataforma;
        j[2] = duracion.toString();
        j[3] = calificacion;
        j[4] = fallos;
        j[5] = sdf.format(fechaAlta);
                
        return j;
    }
}
