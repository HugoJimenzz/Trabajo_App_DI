/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas.dto;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author HugoJiménezAriza
 */
public class PJugar {

    private String nombre;
    private String plataforma;
    private Integer duracion;
    private Date fechaAlta;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    
    public PJugar(String nombre, String plataforma, Integer duracion, Date fechaAlta) {
        this.nombre = nombre;
        this.plataforma = plataforma;
        this.duracion = duracion;
        this.fechaAlta = fechaAlta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public Integer getDuracion() {
        return duracion;
    }

    public void setDuracion(Integer duracion) {
        this.duracion = duracion;
    }
    public Date getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Date fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    
    //pillamos los datos
    public String[] toArrayStringPJ(){
        String[] pj = new String[4];
        pj[0] = nombre ;
        pj[1] = plataforma;
        pj[2] = duracion.toString();
        pj[3] = sdf.format(fechaAlta);
        

        return pj;
    }
    
}
