/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Ventanas.gui;

import Ventanas.dto.Jugados;
import Ventanas.dto.PJugar;
import Ventanas.gui.tablemodels.JugadosTableModel;
import Ventanas.logica.LogicaJugados;
import Ventanas.logica.LogicaPJugar;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import org.netbeans.validation.api.builtin.stringvalidation.BloqMayusValidacion;
import org.netbeans.validation.api.ui.ValidationGroup;

/**
 *
 * @author HugoJiménezAriza
 */
public class DialExpJug extends javax.swing.JDialog {

    private TableRowSorter<DefaultTableModel> sorterJ;

    /**
     * Creates new form DialExpJug
     */
    public DialExpJug(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        refrescarTabla();
//        jComboBoxValoresFiltro.removeAllItems();
//        jComboBoxValoresFiltro.addItem("");

        ValidationGroup group = validationPanelFiltro.getValidationGroup();
        
        group.add(jTextFieldFiltrar, new BloqMayusValidacion());        
//        validacionSelectiva();
//        modeloJCombo();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableJugados = new javax.swing.JTable();
        jTextFieldFiltrar = new javax.swing.JTextField();
        jButtonFiltrar = new javax.swing.JButton();
        jComboBoxFiltrar = new javax.swing.JComboBox<>();
        validationPanelFiltro = new org.netbeans.validation.api.ui.swing.ValidationPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTableJugados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableJugados);

        jTextFieldFiltrar.setText(org.openide.util.NbBundle.getMessage(DialExpJug.class, "DialExpJug.jTextFieldFiltrar.text")); // NOI18N
        jTextFieldFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldFiltrarActionPerformed(evt);
            }
        });

        jButtonFiltrar.setText(org.openide.util.NbBundle.getMessage(DialExpJug.class, "DialExpJug.jButtonFiltrar.text")); // NOI18N
        jButtonFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFiltrarActionPerformed(evt);
            }
        });

        jComboBoxFiltrar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione...", "Nombre", "Plataforma", "Calificacion", "Fallos" }));
        jComboBoxFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxFiltrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 838, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jComboBoxFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(validationPanelFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonFiltrar)
                        .addComponent(jComboBoxFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(validationPanelFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFiltrarActionPerformed
        // TODO add your handling code here:
        RowFilter<DefaultTableModel, Integer> rf = RowFilter.regexFilter(jTextFieldFiltrar.getText(), valorSeleccion());
        sorterJ.setRowFilter(rf);
    }//GEN-LAST:event_jButtonFiltrarActionPerformed

    //NO FUNCIONA
    private void jTextFieldFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldFiltrarActionPerformed
        // TODO add your handling code here:
//        if (jComboBoxFiltrar.getSelectedItem() == "Nombre") {            
//            jTextFieldFiltrar.getText().toLowerCase();
//
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Plataforma") {
//            jTextFieldFiltrar.getText().toUpperCase();
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Duracion") {
//            jTextFieldFiltrar.getText();
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Calificacion") {
//            jTextFieldFiltrar.getText().toUpperCase();
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Fallos") {
//            jTextFieldFiltrar.getText().toUpperCase();
//        }
    }//GEN-LAST:event_jTextFieldFiltrarActionPerformed

    private void jComboBoxFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxFiltrarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxFiltrarActionPerformed

   
    //NO FUNCIONA
    private void modeloJCombo() {
//        if (jComboBoxFiltrar.getSelectedItem() == "Plataforma") {
//            jComboBoxValoresFiltro.removeAllItems();
//
//            List listaP = new ArrayList<>();
//            //"EA","EPIC GAMES","STEAM","UBISOFT","ITCH-o","PIRATA","EMULADOR"
//            listaP.add("GAME PASS");
//            listaP.add("EA");
//            listaP.add("EPIC GAMES");
//            listaP.add("STEAM");
//            listaP.add("UBISOFT");
//            listaP.add("ITCH-io");
//            listaP.add("PIRATA");
//            listaP.add("EMULADOR");
//
//            String[] plataforma = (String[]) listaP.toArray(new String[listaP.size()]);
//            jComboBoxValoresFiltro.setModel(new DefaultComboBoxModel<>(plataforma));
//            
//
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Calificacion") {
//            jComboBoxValoresFiltro.removeAllItems();
//
//            List listaC = new ArrayList<>();
//
//            listaC.add("NEFASTO");
//            listaC.add("ACEPTABLE");
//            listaC.add("BUENO");
//            listaC.add("NOTABLE");
//            listaC.add("GOTY");
//
//            String[] calificacion = (String[]) listaC.toArray(new String[listaC.size()]);
//            jComboBoxValoresFiltro.setModel(new DefaultComboBoxModel<>(calificacion));
//
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Fallos") {
//            jComboBoxValoresFiltro.removeAllItems();
//
//            List listaF = new ArrayList<>();
//
//            listaF.add("SI");
//            listaF.add("NO");
//
//            String[] fallos = (String[]) listaF.toArray(new String[listaF.size()]);
//            jComboBoxValoresFiltro.setModel(new DefaultComboBoxModel<>(fallos));
//        }
    }
    //NO FUNCIONA
    private void validacionSelectiva() {

//        ValidationGroup group = validationPanelFiltro.getValidationGroup();
//
//        if (jComboBoxFiltrar.getSelectedItem() == "Plataforma") {
//            group.add(jTextFieldFiltrar, new BloqMayusValidacion());
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Calificacion") {
//            group.add(jTextFieldFiltrar, new BloqMayusValidacion());
//        } else if (jComboBoxFiltrar.getSelectedItem() == "Fallos") {
//            group.add(jTextFieldFiltrar, new BloqMayusValidacion());
//        }
    }

    private int valorSeleccion() {
        if (jComboBoxFiltrar.getSelectedItem() == "Nombre") {
            return 0;

        } else if (jComboBoxFiltrar.getSelectedItem() == "Plataforma") {
            return 1;
        } else if (jComboBoxFiltrar.getSelectedItem() == "Calificacion") {
            return 3;
        } else if (jComboBoxFiltrar.getSelectedItem() == "Fallos") {
            return 4;
        }
        return 0;
    }

    /**
     * @param args the command line arguments
     */
    private void refrescarTabla() {
        //DEFAULT TABLE MODEL
        DefaultTableModel jug = new DefaultTableModel();
        jug.setColumnIdentifiers(new String[]{"Nombre", "Plataforma", "Duracion", "Calificacion", "Fallos", "Fecha Agregado"});

        //Añadimos directamente los datos a la tabla
        List<Jugados> listaJugados = LogicaJugados.getListaJugados();
        for (Jugados jugados : listaJugados) {
            jug.addRow(jugados.toArrayStringJ());
        }

        jTableJugados.setModel(jug);

        sorterJ = new TableRowSorter<>(jug);//jtm para el TABLEMODEL
        jTableJugados.setRowSorter(sorterJ);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonFiltrar;
    private javax.swing.JComboBox<String> jComboBoxFiltrar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableJugados;
    private javax.swing.JTextField jTextFieldFiltrar;
    private org.netbeans.validation.api.ui.swing.ValidationPanel validationPanelFiltro;
    // End of variables declaration//GEN-END:variables
}
