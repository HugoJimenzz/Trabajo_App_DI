/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Ventanas.gui;

import Ventanas.ActionListener.ALJugados;
import Ventanas.dto.Jugados;
import Ventanas.logica.LogicaJugados;
import java.time.LocalDateTime;
import static java.time.LocalDateTime.now;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author HugoJiménezAriza
 */

public class DialogoJugarAnadir1 extends javax.swing.JDialog {

    private VentanaInicio ventanaInicio;
    
    //INICIALIZAMOS EL JDIALOG
    public DialogoJugarAnadir1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        ventanaInicio = (VentanaInicio) parent;
        
        this.setResizable(false);
        
        initComponents();
        jSpinnerFecha.setVisible(false);

        jButtonAnadir.addActionListener(new ALJugados());
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        jLabelPlataforma = new javax.swing.JLabel();
        jLabelCalificacion = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jComboBoxPlataforma = new javax.swing.JComboBox<>();
        jComboBoxCalificacion = new javax.swing.JComboBox<>();
        jLabelDuracion = new javax.swing.JLabel();
        jLabelFallos = new javax.swing.JLabel();
        jSpinnerDuracion = new javax.swing.JSpinner();
        jComboBoxFallos = new javax.swing.JComboBox<>();
        jButtonAnadir = new javax.swing.JButton();
        jSpinnerFecha = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("Añadir registro a juegos jugados");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabelTitulo)
                .addGap(15, 15, 15))
        );

        jLabelNombre.setText("Nombre");

        jLabelPlataforma.setText("Plataforma");

        jLabelCalificacion.setText("Calificacion");

        jComboBoxPlataforma.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione...", "GAME PASS", "EA", "EPIC GAMES", "EMULADOR", "STEAM", "ITCH-io", "PIRATA", "UBISOFT" }));

        jComboBoxCalificacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione...", "NEFASTO", "ACEPTABLE", "BUENO", "NOTABLE", "GOTY" }));

        jLabelDuracion.setText("Duracion");

        jLabelFallos.setText("Fallos");

        jSpinnerDuracion.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        jComboBoxFallos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione...", "SI", "NO" }));

        jButtonAnadir.setText("Añadir Registro");
        jButtonAnadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAnadirActionPerformed(evt);
            }
        });

        jSpinnerFecha.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), new java.util.Date(1666078544817L), null, java.util.Calendar.DAY_OF_MONTH));
        jSpinnerFecha.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelNombre)
                                .addGap(30, 30, 30)
                                .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabelPlataforma)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBoxPlataforma, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabelCalificacion)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBoxCalificacion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelDuracion)
                                    .addComponent(jLabelFallos))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboBoxFallos, 0, 118, Short.MAX_VALUE)
                                    .addComponent(jSpinnerDuracion)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jSpinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonAnadir, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(90, 90, 90)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombre)
                    .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelPlataforma)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBoxPlataforma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabelDuracion)
                        .addComponent(jSpinnerDuracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCalificacion)
                    .addComponent(jComboBoxCalificacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelFallos)
                    .addComponent(jComboBoxFallos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonAnadir, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
//VALIDACION TRADICIONAL
    
    private boolean validarFormularioTradi() {

        String nombre = jTextFieldNombre.getText();
        if (nombre == null || "".equals(nombre)) {
            JOptionPane.showMessageDialog(this, "Rellene el campo nombre", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String plataforma = (String) jComboBoxPlataforma.getSelectedItem();
        if (plataforma == null || "seleccione...".equals(plataforma)) {
            JOptionPane.showMessageDialog(this, "Rellene el campo plataforma", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        Integer duracion = (Integer) jSpinnerDuracion.getValue();
        if (duracion == null || duracion == 0) {
            JOptionPane.showMessageDialog(this, "Rellene el campo duracion", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String calificacion = (String) jComboBoxCalificacion.getSelectedItem();
        if (calificacion == null || "seleccione...".equals(calificacion)) {
            JOptionPane.showMessageDialog(this, "Rellene el campo calificacion", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String fallos = (String) jComboBoxFallos.getSelectedItem();
        if (fallos == null || "seleccione...".equals(fallos)) {
            JOptionPane.showMessageDialog(this, "Rellene el campo fallos", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void jButtonAnadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAnadirActionPerformed
      
        //LLAMAMOS A LA VALIDACION TRADICIONAL
        if (validarFormularioTradi()) {

            String nombre = jTextFieldNombre.getText();
            String plataforma = (String) jComboBoxPlataforma.getSelectedItem();
            Integer duracion = (Integer) jSpinnerDuracion.getValue();
            String calificacion = (String) jComboBoxCalificacion.getSelectedItem();
            String fallos = (String) jComboBoxFallos.getSelectedItem();
            Date fechaAlta = (Date) jSpinnerFecha.getValue();
            
            //AÑADIMOS LOS DATOS AL OBJETO
            Jugados jugados = new Jugados(nombre, plataforma, duracion, calificacion, fallos, fechaAlta);

            LogicaJugados.anadirJugados(jugados);
            
            //MOSTRAMOS QUE TODO CORRECTO
            JOptionPane.showMessageDialog(this, "Registro añadido correctamente", "Titulo", JOptionPane.INFORMATION_MESSAGE);
            
            //CERRAMOS LA VENTANA
            setVisible(false);
        }
    }//GEN-LAST:event_jButtonAnadirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAnadir;
    private javax.swing.JComboBox<String> jComboBoxCalificacion;
    private javax.swing.JComboBox<String> jComboBoxFallos;
    private javax.swing.JComboBox<String> jComboBoxPlataforma;
    private javax.swing.JLabel jLabelCalificacion;
    private javax.swing.JLabel jLabelDuracion;
    private javax.swing.JLabel jLabelFallos;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelPlataforma;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSpinner jSpinnerDuracion;
    private javax.swing.JSpinner jSpinnerFecha;
    private javax.swing.JTextField jTextFieldNombre;
    // End of variables declaration//GEN-END:variables
}
