/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas.gui.tablemodels;

import Ventanas.dto.PJugar;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author HugoJiménezAriza
 */
public class PorJugarTableModel extends AbstractTableModel {

    private List<PJugar> listPJ;
    private String[] columnas = {"Nombre", "Plataforma", "Duracion", "Fecha Agregado"};
    
    public PorJugarTableModel(List<PJugar> listPJ) {
        this.listPJ = listPJ;
    }

    @Override
    public int getRowCount() {
        return listPJ.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listPJ.get(rowIndex).getNombre();
            case 1:
                return listPJ.get(rowIndex).getPlataforma();
            case 2:
                return listPJ.get(rowIndex).getDuracion();
            case 3:
                return listPJ.get(rowIndex).getFechaAlta();
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }       
}
