/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas.gui.tablemodels;

import Ventanas.dto.Jugados;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author HugoJiménezAriza
 */
public class JugadosTableModel extends AbstractTableModel {

    private List<Jugados> listJ;
    private String[] columnas = {"Nombre", "Plataforma", "Duracion", "Calificación", "Fallos", "Fecha Agregado"};
    
    public JugadosTableModel(List<Jugados> listPJ) {
        this.listJ = listPJ;
    }

    @Override
    public int getRowCount() {
        return listJ.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return listJ.get(rowIndex).getNombre();
            case 1:
                return listJ.get(rowIndex).getPlataforma();
            case 2:
                return listJ.get(rowIndex).getDuracion();
            case 3:
                return listJ.get(rowIndex).getCalificacion();
            case 4:
                return listJ.get(rowIndex).getFallos();
            case 5:
                return listJ.get(rowIndex).getFechaAlta();
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }       
}
