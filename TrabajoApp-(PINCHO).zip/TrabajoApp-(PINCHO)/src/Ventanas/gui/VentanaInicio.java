/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas.gui;

import Ventanas.ActionListener.ALAnadirJugados;
import Ventanas.ActionListener.ALAnadirPjug;
import Ventanas.dto.Jugados;
import Ventanas.dto.PJugar;
import Ventanas.dto.Usuario;
import Ventanas.gui.tablemodels.JugadosTableModel;
import Ventanas.gui.tablemodels.PorJugarTableModel;
import Ventanas.logica.LogicaJugados;
import Ventanas.logica.LogicaPJugar;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.RowSorter.SortKey;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import org.openide.util.Exceptions;

/**
 *
 * @author HugoJiménezAriza
 */
public class VentanaInicio extends javax.swing.JFrame {

    //INICIALIZAMOS COMPONENTES
    public VentanaInicio() {
        initComponents();
        this.setIconImage(new ImageIcon(getClass().getResource("/Ventanas/gui/imgs/libreria.jpg")).getImage());

        //REFRESCAMOS LA TABLA CADA VEZ QUE VOLVAMOS AL INICIO
        refrescarTabla();

        //OBLIGAMOS AL USUARIO A INICIAR SESION
        jMenuPorjugar.setEnabled(false);
        jMenuJugados.setEnabled(false);

        jMenuItemPerfil.setVisible(false);
        jMenuItemPerfil.setEnabled(false);

        jMenuItemCerraSesion.setVisible(false);
        jMenuItemCerraSesion.setEnabled(false);

        jMenuUsuario.setText("Nuevo Usuario");

    }
//INICIALIZA Y GENERA LOS MODELOS DE TABLAS  
    //Cambiamos nombre del metodo de inicializar a refrescar con CTRL+R

    private void refrescarTabla() {

        DefaultTableModel pj = new DefaultTableModel();
        pj.setColumnIdentifiers(new String[]{"Nombre", "Plataforma", "Duracion", "Fecha Agregado"});

        //Añadimos directamente los datos a la tabla
        List<PJugar> listaPJugar = LogicaPJugar.getListaPJugar();
        for (PJugar pjugar : listaPJugar) {
            pj.addRow(pjugar.toArrayStringPJ());
        }

        jTablePorJug.setModel(pj);

        DefaultTableModel jug = new DefaultTableModel();
        jug.setColumnIdentifiers(new String[]{"Nombre", "Plataforma", "Duracion", "Calificacion", "Fallos", "Fecha Agregado"});

        //Añadimos directamente los datos a la tabla
        List<Jugados> listaJugados = LogicaJugados.getListaJugados();
        for (Jugados jugados : listaJugados) {
            jug.addRow(jugados.toArrayStringJ());
        }

        jTableJugados.setModel(jug);

//        //TABLE MODEL (DA ERROR CON SimpleDateFormat)
//        //TABLA POR JUGAR
//        PorJugarTableModel pjtm = new PorJugarTableModel(LogicaPJugar.getListaPJugar());
//        jTablePorJug.setModel(pjtm);
//
//        //TABLA JUGADOS
//        JugadosTableModel jtm = new JugadosTableModel(LogicaJugados.getListaJugados());
//        jTableJugados.setModel(jtm);
        //ORDENACION DE TABLAS POR COLUMNAS                
        //TABLA POR JUGAR
        //TableRowSorter<PorJugarTableModel> sorterPJ = new TableRowSorter<>(pjtm);//pjtm para el TABLEMODEL
        TableRowSorter<DefaultTableModel> sorterPJ = new TableRowSorter<>(pj);//pj para el DEFAULTABLEMODEL
        jTablePorJug.setRowSorter(sorterPJ);

        //TABLA JUGADOS
        //TableRowSorter<JugadosTableModel> sorterJ = new TableRowSorter<>(jtm);//jtm para el TABLEMODEL
        TableRowSorter<DefaultTableModel> sorterJ = new TableRowSorter<>(jug);//jUG para el DEFAULTABLEMODEL
        jTableJugados.setRowSorter(sorterJ);

        //Ordenar por defecto con una columna
//        List<SortKey> sortKeys = new ArrayList<>();
//        sortKeys.add(new SortKey(0, SortOrder.ASCENDING));
//        sorterPJ.setSortKeys(sortKeys); 
    }

//AÑADIMOS DATOS DE REGISTRO A LA VENTANA
    public void establecerUsuario(Usuario usuario) {

        jLabelUsuario.setText("Bienvenido a la aplicacion: " + usuario.getNombre());

        jMenuPorjugar.setEnabled(true);

        jMenuJugados.setEnabled(true);

//        jMenuItemPerfil.setVisible(true);
//        jMenuItemPerfil.setEnabled(true);
        jMenuItemIniciosesion.setEnabled(false);
        jMenuItemIniciosesion.setVisible(false);

        jMenuItemCerraSesion.setVisible(true);
        jMenuItemCerraSesion.setEnabled(true);

        jMenuUsuario.setText(usuario.getNombreUsuario());

        if (usuario.getSexo() == "Masculino") {
            ImageIcon iconM = new ImageIcon(System.getProperty("user.dir") + "/src/Ventanas/gui/imgs/usuarioM (1).png");
            jMenuUsuario.setIcon(iconM);

        } else if (usuario.getSexo() == "Femenino") {
            ImageIcon iconF = new ImageIcon(System.getProperty("user.dir") + "/src/Ventanas/gui/imgs/usuarioF (1).png");
            jMenuUsuario.setIcon(iconF);

        } else {
            ImageIcon iconO = new ImageIcon(System.getProperty("user.dir") + "/src/Ventanas/gui/imgs/usu (1).png");
            jMenuUsuario.setIcon(iconO);

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelSaludo = new javax.swing.JLabel();
        jScrollPanePJ = new javax.swing.JScrollPane();
        jTablePorJug = new javax.swing.JTable();
        jPanelPJ = new javax.swing.JPanel();
        jLabelPorJug = new javax.swing.JLabel();
        jPanelJ = new javax.swing.JPanel();
        jLabelJug = new javax.swing.JLabel();
        jScrollPaneJ = new javax.swing.JScrollPane();
        jTableJugados = new javax.swing.JTable();
        jLabelUsuario = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuInicio = new javax.swing.JMenu();
        jMenuPorjugar = new javax.swing.JMenu();
        jMenuItemPJugAñadir = new javax.swing.JMenuItem();
        jMenuItemExportarPJ = new javax.swing.JMenuItem();
        jMenuJugados = new javax.swing.JMenu();
        jMenuItemJugAñadir = new javax.swing.JMenuItem();
        jMenuItemExportarJ = new javax.swing.JMenuItem();
        jMenuUsuario = new javax.swing.JMenu();
        jMenuItemIniciosesion = new javax.swing.JMenuItem();
        jMenuItemPerfil = new javax.swing.JMenuItem();
        jMenuItemCerraSesion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTablePorJug.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "Plataforma", "Duracion", "Fecha Agregado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Double.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTablePorJug.setShowGrid(true);
        jScrollPanePJ.setViewportView(jTablePorJug);

        jLabelPorJug.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabelPorJug.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPorJug.setText("JUEGOS POR JUGAR");
        jLabelPorJug.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanelPJLayout = new javax.swing.GroupLayout(jPanelPJ);
        jPanelPJ.setLayout(jPanelPJLayout);
        jPanelPJLayout.setHorizontalGroup(
            jPanelPJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelPJLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabelPorJug, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanelPJLayout.setVerticalGroup(
            jPanelPJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelPJLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabelPorJug)
                .addGap(15, 15, 15))
        );

        jLabelJug.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabelJug.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelJug.setText("JUEGOS COMPLETADOS");
        jLabelJug.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabelJug.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanelJLayout = new javax.swing.GroupLayout(jPanelJ);
        jPanelJ.setLayout(jPanelJLayout);
        jPanelJLayout.setHorizontalGroup(
            jPanelJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelJLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabelJug, javax.swing.GroupLayout.DEFAULT_SIZE, 669, Short.MAX_VALUE)
                .addGap(9, 9, 9))
        );
        jPanelJLayout.setVerticalGroup(
            jPanelJLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelJLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabelJug)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jTableJugados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Plataforma", "Calificacion", "Duracion", "Fallos", "Fecha Agregado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPaneJ.setViewportView(jTableJugados);

        jLabelUsuario.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabelUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelUsuario.setText("Por favor, Inicie sesión para usar la aplicación y guardar sus datos.");
        jLabelUsuario.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabelUsuario.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jMenuInicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/gui/imgs/casa (1) (1).png"))); // NOI18N
        jMenuInicio.setText("Inicio");
        jMenuInicio.setFont(new java.awt.Font("Carlito", 0, 18)); // NOI18N
        jMenuInicio.setIconTextGap(3);
        jMenuBar1.add(jMenuInicio);

        jMenuPorjugar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/gui/imgs/añadir (1) (1).png"))); // NOI18N
        jMenuPorjugar.setText("Por Jugar");
        jMenuPorjugar.setFont(new java.awt.Font("Carlito", 0, 18)); // NOI18N
        jMenuPorjugar.setHideActionText(true);
        jMenuPorjugar.setIconTextGap(2);

        jMenuItemPJugAñadir.setText("Añadir");
        jMenuItemPJugAñadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemPJugAñadirActionPerformed(evt);
            }
        });
        jMenuPorjugar.add(jMenuItemPJugAñadir);

        jMenuItemExportarPJ.setText("Exportar");
        jMenuItemExportarPJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemExportarPJActionPerformed(evt);
            }
        });
        jMenuPorjugar.add(jMenuItemExportarPJ);

        jMenuBar1.add(jMenuPorjugar);

        jMenuJugados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/gui/imgs/check (1) (1).png"))); // NOI18N
        jMenuJugados.setText("Jugados");
        jMenuJugados.setFont(new java.awt.Font("Carlito", 0, 18)); // NOI18N
        jMenuJugados.setIconTextGap(3);

        jMenuItemJugAñadir.setText("Añadir");
        jMenuItemJugAñadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemJugAñadirActionPerformed(evt);
            }
        });
        jMenuJugados.add(jMenuItemJugAñadir);

        jMenuItemExportarJ.setText("Exportar");
        jMenuItemExportarJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemExportarJActionPerformed(evt);
            }
        });
        jMenuJugados.add(jMenuItemExportarJ);

        jMenuBar1.add(jMenuJugados);

        jMenuUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/gui/imgs/newUser (1) (2).png"))); // NOI18N
        jMenuUsuario.setText("Usuario");
        jMenuUsuario.setFont(new java.awt.Font("Carlito", 0, 16)); // NOI18N
        jMenuUsuario.setIconTextGap(2);

        jMenuItemIniciosesion.setText("Registro");
        jMenuItemIniciosesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemIniciosesionActionPerformed(evt);
            }
        });
        jMenuUsuario.add(jMenuItemIniciosesion);

        jMenuItemPerfil.setText("Perfil");
        jMenuItemPerfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemPerfilActionPerformed(evt);
            }
        });
        jMenuUsuario.add(jMenuItemPerfil);

        jMenuItemCerraSesion.setText("Cerrar Sesión");
        jMenuItemCerraSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCerraSesionActionPerformed(evt);
            }
        });
        jMenuUsuario.add(jMenuItemCerraSesion);

        jMenuBar1.add(jMenuUsuario);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPaneJ, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanelPJ, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanelJ, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPanePJ, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelSaludo)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(284, 284, 284)
                        .addComponent(jLabelSaludo))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanelPJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPanePJ, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanelJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPaneJ, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//ABRE DIALOGO AÑADIR JUEGOS POR JUGAR
    private void jMenuItemPJugAñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemPJugAñadirActionPerformed
        // TODO add your handling code here:
        jMenuItemPJugAñadir.addActionListener(new ALAnadirPjug());
        DialogoPorJugarAñadir1 pantallaPjugar = new DialogoPorJugarAñadir1(this, true);
        pantallaPjugar.setVisible(true);
        refrescarTabla();


    }//GEN-LAST:event_jMenuItemPJugAñadirActionPerformed
//ABRE DIALOGO AÑADIR JUEGOS JUGADOS
    private void jMenuItemJugAñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemJugAñadirActionPerformed
        // TODO add your handling code here:
        jMenuItemJugAñadir.addActionListener(new ALAnadirJugados());
        DialogoJugarAnadir1 pantallaJugados = new DialogoJugarAnadir1(this, true);
        //DialogoJugarAñadir pantallaJugados = new DialogoJugarAñadir(this, true);
        pantallaJugados.setVisible(true);
        refrescarTabla();


    }//GEN-LAST:event_jMenuItemJugAñadirActionPerformed
//ABRE DIALOGO REGISTRO
    private void jMenuItemIniciosesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemIniciosesionActionPerformed
        // TODO add your handling code here:
        DialogoRegistro pantallaRegistro = new DialogoRegistro(this, true);
        pantallaRegistro.setVisible(true);


    }//GEN-LAST:event_jMenuItemIniciosesionActionPerformed

    private void jMenuItemExportarPJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemExportarPJActionPerformed
        //USAMOS UN JOPTION PANE PARA EXPORTAR NUESTROS DATOS A UN TXT
        int dialogButton = JOptionPane.YES_NO_OPTION;

        if (JOptionPane.showConfirmDialog(null, "¿Quiere exportar los datos?", "EXPORTAR",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            // yes option

            //MOSTRAMOS EL DIALOGO DE EXPORTACION
            DialExpPJ pantallaExPJ = new DialExpPJ(this, true);
            pantallaExPJ.setVisible(true);
        } else {
            // no option
        }

//        
    }//GEN-LAST:event_jMenuItemExportarPJActionPerformed

    private void jMenuItemExportarJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemExportarJActionPerformed
        //USAMOS UN JOPTION PANE PARA EXPORTAR NUESTROS DATOS A UN TXT
        int dialogButton = JOptionPane.YES_NO_OPTION;

        if (JOptionPane.showConfirmDialog(null, "¿Quiere exportar los datos?", "EXPORTAR",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            // yes option

            //MOSTRAMOS EL DIALOGO DE EXPORTACION
            DialExpJug pantallaExJug = new DialExpJug(this, true);
            pantallaExJug.setVisible(true);

        } else {
            // no option
        }
    }//GEN-LAST:event_jMenuItemExportarJActionPerformed

//ABRE LA PANTALLA PERFIL (DESHABILITADA POR FALLOS)
    private void jMenuItemPerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemPerfilActionPerformed
        // TODO add your handling code here:
        DialogoPerfil pantallaPerfil = new DialogoPerfil(this, true);
        pantallaPerfil.setVisible(true);
    }//GEN-LAST:event_jMenuItemPerfilActionPerformed
 //CERRAMOS SESION PARA AÑADR UN NUEVO USUARIO
    private void jMenuItemCerraSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCerraSesionActionPerformed
        //CERRAMOS SESION PARA AÑADR UN NUEVO USUARIO

        DialogoRegistro pantallaRegistro = new DialogoRegistro(this, true);
        pantallaRegistro.setVisible(true);

        jTableJugados.removeAll();
        jTablePorJug.removeAll();
                
        
        
    }//GEN-LAST:event_jMenuItemCerraSesionActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaInicio().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabelJug;
    private javax.swing.JLabel jLabelPorJug;
    private javax.swing.JLabel jLabelSaludo;
    private javax.swing.JLabel jLabelUsuario;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuInicio;
    private javax.swing.JMenuItem jMenuItemCerraSesion;
    private javax.swing.JMenuItem jMenuItemExportarJ;
    private javax.swing.JMenuItem jMenuItemExportarPJ;
    private javax.swing.JMenuItem jMenuItemIniciosesion;
    private javax.swing.JMenuItem jMenuItemJugAñadir;
    private javax.swing.JMenuItem jMenuItemPJugAñadir;
    private javax.swing.JMenuItem jMenuItemPerfil;
    private javax.swing.JMenu jMenuJugados;
    private javax.swing.JMenu jMenuPorjugar;
    private javax.swing.JMenu jMenuUsuario;
    private javax.swing.JPanel jPanelJ;
    private javax.swing.JPanel jPanelPJ;
    private javax.swing.JScrollPane jScrollPaneJ;
    private javax.swing.JScrollPane jScrollPanePJ;
    private javax.swing.JTable jTableJugados;
    private javax.swing.JTable jTablePorJug;
    // End of variables declaration//GEN-END:variables
}
