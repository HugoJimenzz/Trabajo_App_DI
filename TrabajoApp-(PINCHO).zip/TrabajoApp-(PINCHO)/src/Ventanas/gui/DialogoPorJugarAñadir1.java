/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Ventanas.gui;

import Ventanas.ActionListener.ALPJugar;
import Ventanas.dto.PJugar;
import Ventanas.logica.LogicaPJugar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author HugoJiménezAriza
 */
public class DialogoPorJugarAñadir1 extends javax.swing.JDialog {

    private VentanaInicio ventanaInicio;

    //INICIALIZAMOS EL JDIALOG
    public DialogoPorJugarAñadir1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        ventanaInicio = (VentanaInicio)parent;
        
        this.setResizable(false);
        
        initComponents();
 
        jButtonAñadir.addActionListener(new ALPJugar());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelNombre = new javax.swing.JLabel();
        jLabelPlataforma = new javax.swing.JLabel();
        jLabelDuracion = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jComboBoxPlataforma = new javax.swing.JComboBox<>();
        jSpinnerDuracion = new javax.swing.JSpinner();
        jButtonAñadir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabelTitulo = new javax.swing.JLabel();
        jSpinnerFecha = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabelNombre.setText("Nombre");

        jLabelPlataforma.setText("Plataforma");

        jLabelDuracion.setText("Duracion");

        jComboBoxPlataforma.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccione...", "GAME PASS", "EA", "EPIC GAMES", "EMULADOR", "STEAM", "ITCH-io", "PIRATA", "UBISOFT" }));

        jButtonAñadir.setText("Añadir Registro");
        jButtonAñadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAñadirActionPerformed(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabelTitulo.setText("Añadir registro a juegos por jugar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabelTitulo)
                .addGap(14, 14, 14))
        );

        jSpinnerFecha.setModel(new javax.swing.SpinnerDateModel());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelPlataforma))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jComboBoxPlataforma, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabelDuracion)
                                .addGap(18, 18, 18)
                                .addComponent(jSpinnerDuracion))
                            .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(jButtonAñadir, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSpinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelPlataforma)
                    .addComponent(jComboBoxPlataforma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelDuracion)
                    .addComponent(jSpinnerDuracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addComponent(jButtonAñadir, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSpinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    //VALIDAMOS TRADICIONALMENTE
    private boolean validarFormularioTradi() {

        String nombre = jTextFieldNombre.getText();
        if (nombre == null || "".equals(nombre)) {
            JOptionPane.showMessageDialog(this, "Rellene el campo nombre", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String plataforma = (String) jComboBoxPlataforma.getSelectedItem();
        if (plataforma == null || "seleccione...".equals(plataforma)) {
            JOptionPane.showMessageDialog(this, "Rellene el campo plataforma", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        Integer duracion = (Integer) jSpinnerDuracion.getValue();
        if (duracion == null || duracion == 0) {
            JOptionPane.showMessageDialog(this, "Rellene el campo duracion", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
    
    private void jButtonAñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAñadirActionPerformed
        // TODO add your handling code here:
        
        //COMPROVAMOS LA VALIDACION
        if (validarFormularioTradi()) {
            
            String nombre = jTextFieldNombre.getText();
            String plataforma = (String)jComboBoxPlataforma.getSelectedItem();
            Integer duracion = (Integer)jSpinnerDuracion.getValue();
            Date fechaAlta = (Date)jSpinnerFecha.getValue();
            
            //AÑADIMOS LOS DATOS AL OBJETO
            PJugar pjugar = new PJugar(nombre, plataforma, duracion, fechaAlta);
            

            //como hemos creado la logica podemos ahorrarnos esta llamada
            //ventanaInicio.anadirPJugar(pjugar);

            LogicaPJugar.anadirPJugar(pjugar);
            
            //MOSTRAMOS MENSAJE SI TODO ESTA CORECTO
            JOptionPane.showMessageDialog(this, "Registro añadido correctamente","Titulo",JOptionPane.INFORMATION_MESSAGE);

            //CERRAMOS LA VENTANA
            setVisible(false);
        }
        
    }//GEN-LAST:event_jButtonAñadirActionPerformed
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAñadir;
    private javax.swing.JComboBox<String> jComboBoxPlataforma;
    private javax.swing.JLabel jLabelDuracion;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelPlataforma;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSpinner jSpinnerDuracion;
    private javax.swing.JSpinner jSpinnerFecha;
    private javax.swing.JTextField jTextFieldNombre;
    // End of variables declaration//GEN-END:variables
}
