/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Ventanas.gui;

import Ventanas.dto.PJugar;
import Ventanas.gui.tablemodels.PorJugarTableModel;
import Ventanas.logica.LogicaPJugar;
import java.util.List;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import org.netbeans.validation.api.builtin.stringvalidation.BloqMayusValidacion;
import org.netbeans.validation.api.ui.ValidationGroup;

/**
 *
 * @author HugoJiménezAriza
 */
public class DialExpPJ extends javax.swing.JDialog {

    private TableRowSorter<DefaultTableModel> sorterPJ;
    /**
     * Creates new form DialExpPJ
     */
    public DialExpPJ(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        refrescarTabla();
        
        ValidationGroup group = validationPanelFiltro.getValidationGroup();
        
        group.add(jTextFieldFiltrar, new BloqMayusValidacion());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePorJug = new javax.swing.JTable();
        jComboBoxFiltrar = new javax.swing.JComboBox<>();
        jTextFieldFiltrar = new javax.swing.JTextField();
        jButtonFiltrar = new javax.swing.JButton();
        validationPanelFiltro = new org.netbeans.validation.api.ui.swing.ValidationPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTablePorJug.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTablePorJug);

        jComboBoxFiltrar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione...", "Nombre", "Plataforma", "Calificacion", "Fallos" }));

        jTextFieldFiltrar.setText(org.openide.util.NbBundle.getMessage(DialExpPJ.class, "DialExpPJ.jTextFieldFiltrar.text")); // NOI18N
        jTextFieldFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldFiltrarActionPerformed(evt);
            }
        });

        jButtonFiltrar.setText(org.openide.util.NbBundle.getMessage(DialExpPJ.class, "DialExpPJ.jButtonFiltrar.text")); // NOI18N
        jButtonFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFiltrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 838, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jComboBoxFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(validationPanelFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonFiltrar)
                        .addComponent(jComboBoxFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(validationPanelFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 //NO FUNCIONA
    private void jTextFieldFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldFiltrarActionPerformed
        // TODO add your handling code here:
        //        if (jComboBoxFiltrar.getSelectedItem() == "Nombre") {
            //            jTextFieldFiltrar.getText().toLowerCase();
            //
            //        } else if (jComboBoxFiltrar.getSelectedItem() == "Plataforma") {
            //            jTextFieldFiltrar.getText().toUpperCase();
            //        } else if (jComboBoxFiltrar.getSelectedItem() == "Duracion") {
            //            jTextFieldFiltrar.getText();
            //        } else if (jComboBoxFiltrar.getSelectedItem() == "Calificacion") {
            //            jTextFieldFiltrar.getText().toUpperCase();
            //        } else if (jComboBoxFiltrar.getSelectedItem() == "Fallos") {
            //            jTextFieldFiltrar.getText().toUpperCase();
            //        }
    }//GEN-LAST:event_jTextFieldFiltrarActionPerformed

    private void jButtonFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFiltrarActionPerformed
        // TODO add your handling code here:
        RowFilter<DefaultTableModel, Integer> rf = RowFilter.regexFilter(jTextFieldFiltrar.getText(), valorSeleccion());
        sorterPJ.setRowFilter(rf);
    }//GEN-LAST:event_jButtonFiltrarActionPerformed

    /**
     * @param args the command line arguments
     */
    
    private int valorSeleccion() {
        if (jComboBoxFiltrar.getSelectedItem() == "Nombre") {
            return 0;

        } else if (jComboBoxFiltrar.getSelectedItem() == "Plataforma") {
            return 1;
        } else if (jComboBoxFiltrar.getSelectedItem() == "Calificacion") {
            return 3;
        } else if (jComboBoxFiltrar.getSelectedItem() == "Fallos") {
            return 4;
        }
        return 0;
    }
    
    private void refrescarTabla() {
        //TABLE MODEL POR JUGAR
//        PorJugarTableModel pjtm = new PorJugarTableModel(LogicaPJugar.getListaPJugar());
//        jTablePorJug.setModel(pjtm);
//        
//        TableRowSorter<PorJugarTableModel> sorterPJ = new TableRowSorter<>(pjtm);
//        jTablePorJug.setRowSorter(sorterPJ);
        
        //DEFAULT TABLE MODEL POR JUGAR
        DefaultTableModel pj = new DefaultTableModel();
        pj.setColumnIdentifiers(new String[]{"Nombre", "Plataforma", "Duracion", "Fecha Agregado"});

        //Añadimos directamente los datos a la tabla
        List<PJugar> listaPJugar = LogicaPJugar.getListaPJugar();
        for (PJugar pjugar : listaPJugar) {
            pj.addRow(pjugar.toArrayStringPJ());
        }

        jTablePorJug.setModel(pj);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonFiltrar;
    private javax.swing.JComboBox<String> jComboBoxFiltrar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePorJug;
    private javax.swing.JTextField jTextFieldFiltrar;
    private org.netbeans.validation.api.ui.swing.ValidationPanel validationPanelFiltro;
    // End of variables declaration//GEN-END:variables
}
