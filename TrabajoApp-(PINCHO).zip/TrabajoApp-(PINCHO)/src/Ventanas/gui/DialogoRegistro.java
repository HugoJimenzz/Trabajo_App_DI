/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Ventanas.gui;

import Ventanas.ActionListener.ALCreacionUsuario;
import Ventanas.dto.Usuario;
import java.util.Date;
import java.util.Locale;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.netbeans.validation.api.builtin.stringvalidation.ContrasenaValidacion;
import org.netbeans.validation.api.builtin.stringvalidation.LongitudUsuarioValidacion;
import org.netbeans.validation.api.builtin.stringvalidation.MayusculasValidacion;
import org.netbeans.validation.api.builtin.stringvalidation.SexoValidacion;
import org.netbeans.validation.api.builtin.stringvalidation.StringValidators;
import org.netbeans.validation.api.ui.ValidationGroup;
import org.openide.util.Exceptions;

/**
 *
 * @author HugoJiménezAriza
 */
public class DialogoRegistro extends javax.swing.JDialog {

    private VentanaInicio ventanaInicio;

    //INICIALIZAMOS EL JDIALOG
    public DialogoRegistro(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        ventanaInicio = (VentanaInicio) parent;
        
        //LLAMAMOS A LA VALIDACION EN CASTELLANO QUE CREAMOS
        validacionCastellano();

        initComponents();

        jButtonEnviar.setEnabled(false);
        
        this.setResizable(false);
        
        //CREAMOS LOS DISTINTOS MENSAJES DE VALIDACION
        ValidationGroup group = validationPanelUsuario.getValidationGroup();
        group.add(jTextFieldNombre, StringValidators.REQUIRE_NON_EMPTY_STRING, StringValidators.NO_WHITESPACE, new MayusculasValidacion());

        group.add(jTextFieldUsuario, StringValidators.REQUIRE_NON_EMPTY_STRING, StringValidators.NO_WHITESPACE, new LongitudUsuarioValidacion());

        group.add(jPasswordFieldContrasena, StringValidators.REQUIRE_NON_EMPTY_STRING, StringValidators.NO_WHITESPACE, new ContrasenaValidacion());

        group.add(jTextFieldEmail, StringValidators.REQUIRE_NON_EMPTY_STRING, StringValidators.NO_WHITESPACE, StringValidators.EMAIL_ADDRESS);
        
        group.add(jComboBoxSexo, new SexoValidacion());
        
        
        //group.add(jSpinnerFechaNaci,);
        //Solo funciona en la de nombre
        
        //AÑADIMOS EL LISTENER QUE PERMITE LOS MENSAJES
        validationPanelUsuario.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if (validationPanelUsuario.getProblem() == null) {
                    jButtonEnviar.setEnabled(true);
                } else {
                    jButtonEnviar.setEnabled(false);
                }
            }
        });

        jButtonEnviar.addActionListener(new ALCreacionUsuario());
    }
    
    //CARGAMOS EL PAQUETE BUNDLE EN CASTELLANO
    public void validacionCastellano() {
        Locale.setDefault(new Locale("es", "ES"));
        //new ValidacionLibreria().setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelNombre = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jLabelUsuario = new javax.swing.JLabel();
        jTextFieldUsuario = new javax.swing.JTextField();
        jLabelEmail = new javax.swing.JLabel();
        jTextFieldEmail = new javax.swing.JTextField();
        jLabelContrasena = new javax.swing.JLabel();
        jLabelFechaNaci = new javax.swing.JLabel();
        jSpinnerFechaNaci = new javax.swing.JSpinner();
        jButtonEnviar = new javax.swing.JButton();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelSexo = new javax.swing.JLabel();
        jPasswordFieldContrasena = new javax.swing.JPasswordField();
        validationPanelUsuario = new org.netbeans.validation.api.ui.swing.ValidationPanel();
        jComboBoxSexo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabelNombre.setText("Nombre");

        jTextFieldNombre.setName("Nombre"); // NOI18N

        jLabelUsuario.setText("Nombre Usuario");

        jTextFieldUsuario.setName("Usuario"); // NOI18N

        jLabelEmail.setText("Email");

        jTextFieldEmail.setName("E-Mail"); // NOI18N

        jLabelContrasena.setText("Contraseña");

        jLabelFechaNaci.setText("Fecha nacimiento");

        jSpinnerFechaNaci.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), null, new java.util.Date(), java.util.Calendar.DAY_OF_MONTH));
        jSpinnerFechaNaci.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jButtonEnviar.setText("Añadir Usuario");
        jButtonEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEnviarActionPerformed(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("Iniciar Sesión");

        jLabelSexo.setText("Sexo");

        jComboBoxSexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione...", "Masculino", "Femenino", "Otro" }));
        jComboBoxSexo.setName("Sexo"); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(validationPanelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelFechaNaci)
                            .addComponent(jLabelNombre, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelEmail, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldNombre)
                            .addComponent(jTextFieldEmail)
                            .addComponent(jSpinnerFechaNaci, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelUsuario, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelContrasena, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelSexo, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(28, 28, 28)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(jPasswordFieldContrasena)
                    .addComponent(jComboBoxSexo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombre)
                    .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelUsuario)
                    .addComponent(jTextFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEmail)
                    .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelContrasena)
                    .addComponent(jPasswordFieldContrasena, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelFechaNaci)
                    .addComponent(jSpinnerFechaNaci, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelSexo)
                    .addComponent(jComboBoxSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(validationPanelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jButtonEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEnviarActionPerformed
        // TODO add your handling code here:
        //PILLAMOS LOS DATOS DEL REGISTRO
        String nombre = jTextFieldNombre.getText();
        String nombreU = jTextFieldUsuario.getText();
        String email = jTextFieldEmail.getText();
        String contrasena = jPasswordFieldContrasena.getText();
        Date fechaNaci = (Date) jSpinnerFechaNaci.getValue();
        String sexo = (String) jComboBoxSexo.getSelectedItem();
        
        //LOS CARGAMOS AL OBJETO
        Usuario usuario = new Usuario(nombre, nombreU, email, contrasena, fechaNaci, sexo);
        
        //ENVIAMOS LOS DATOS
        ventanaInicio.establecerUsuario(usuario);                      
        
        //MOSTRAMOS MENSAJE DE CONFIRMACION
        JOptionPane.showMessageDialog(this, "Usuario añadido correctamente", "Titulo", JOptionPane.INFORMATION_MESSAGE);
        
        //CERRAMOS LA PANTALLA
        setVisible(false);
    }//GEN-LAST:event_jButtonEnviarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonEnviar;
    private javax.swing.JComboBox<String> jComboBoxSexo;
    private javax.swing.JLabel jLabelContrasena;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelFechaNaci;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelSexo;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JLabel jLabelUsuario;
    private javax.swing.JPasswordField jPasswordFieldContrasena;
    private javax.swing.JSpinner jSpinnerFechaNaci;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldUsuario;
    private org.netbeans.validation.api.ui.swing.ValidationPanel validationPanelUsuario;
    // End of variables declaration//GEN-END:variables
}
