/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.netbeans.validation.api.builtin.stringvalidation;

import org.netbeans.validation.api.Problems;
import org.openide.util.NbBundle;

/**
 *
 * @author HugoJiménezAriza
 */
public class LongitudUsuarioValidacion extends StringValidator{

    @Override
    public void validate(Problems problems, String compName, String texto) {
        if (texto.length() > 25){
            String msg = NbBundle.getMessage(this.getClass(), "MSG_USU_LONG",compName);
            problems.add(msg);
        }
        
        if (texto.length() < 5){
            String msg = NbBundle.getMessage(this.getClass(), "MSG_USU_SHRT",compName);
            problems.add(msg);
        }
    }
    
}
