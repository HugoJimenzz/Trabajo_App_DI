/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.netbeans.validation.api.builtin.stringvalidation;

import java.awt.font.NumericShaper;
import java.util.OptionalInt;
import java.util.stream.IntStream;
import static java.util.stream.IntStream.range;
import org.netbeans.validation.api.Problems;
import org.openide.util.NbBundle;

/**
 *
 * @author HugoJiménezAriza
 */
public class ContrasenaValidacion extends StringValidator {

    @Override
    public void validate(Problems problems, String compName, String texto) {
        if (texto.length() > 25) {
            String msg = NbBundle.getMessage(this.getClass(), "MSG_PSW_LONG", compName);
            problems.add(msg);
        }

        if (texto.length() < 5) {
            String msg = NbBundle.getMessage(this.getClass(), "MSG_PSW_SHRT", compName);
            problems.add(msg);
        }

//        if (!Character.isUpperCase(texto.charAt(0))) {
//            String msg = NbBundle.getMessage(this.getClass(), "MSG_MAYUSCULAS", compName);
//            problems.add(msg);
//        }
//
//        //CREAMOS UN RANGO PARA QUE DETECTE SI EN TODA LA CONTRASEÑA HAY ALGUNA MAYUSCULA
//        //1. int[] -> IntStream
//        IntStream stream = range(0, 25);
//
//        // 2. OptionalInt
//        OptionalInt first = stream.findFirst();
//
//        // 3. getAsInt()
//        int rango = first.getAsInt();
//
//        if (!Character.isUpperCase(texto.charAt(rango))) {
//            String msg = NbBundle.getMessage(this.getClass(), "MSG_PSW_UPPER", compName);
//            problems.add(msg);
//        }
    }

}
