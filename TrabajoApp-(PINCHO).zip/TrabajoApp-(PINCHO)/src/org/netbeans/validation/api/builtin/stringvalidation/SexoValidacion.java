/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.netbeans.validation.api.builtin.stringvalidation;

import org.netbeans.validation.api.Problems;
import org.openide.util.NbBundle;

/**
 *
 * @author HugoJiménezAriza
 */

//CREAMOS UNA VALIDACION QUE DETECTE SI HEMOS SELECIONADO ALGUN SEXO
public class SexoValidacion extends StringValidator{

    @Override
    public void validate(Problems problems, String compName, String texto) {
        if ("Seleccione...".equals(texto)){
            String msgS = NbBundle.getMessage(this.getClass(), "MSG_SEXO",compName);
            problems.add(msgS);
        }
    }
    
}
