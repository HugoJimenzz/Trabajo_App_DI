/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.netbeans.validation.api.builtin.stringvalidation;

import org.netbeans.validation.api.Problems;
import org.openide.util.NbBundle;

/**
 *
 * @author HugoJiménezAriza
 */

//CREAMOS UNA VALIDACION PROPIA QUE DETECTE SI EL NOMBRE NO EMPIEZA POR MAYUSCULAS
public class MayusculasValidacion extends StringValidator{

    @Override
    public void validate(Problems problems, String compName, String texto) {
        
        if ((!"".equals(texto)) && !Character.isUpperCase(texto.charAt(0))){
            String msg = NbBundle.getMessage(this.getClass(), "MSG_MAYUSCULAS",compName);
            problems.add(msg);
        }
    }    
    
}
